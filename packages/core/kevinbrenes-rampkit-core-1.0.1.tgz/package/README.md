# 🇧🇷 @kevinbrenes/rampkit-core — Multi-Anchor Router SDK for Stellar

> Enterprise Multi-Anchor Router SDK for Stellar — Unified API routing for Etherfuse, Manteca, and Koywe fiat ramps in LATAM.

## 🚀 Features

- **Smart Rate Routing**: Queries quotes from Etherfuse, Manteca, and Koywe in parallel.
- **Etherfuse Sandbox Integration**: Live connection to Etherfuse Sandbox (`/ramp/quote`, `/ramp/order`, `/ramp/orders`).
- **SEP-24 Standardized Interfaces**: Unified TypeScript types for BRL (PIX), MXN (SPEI), CLP (Khipu), USD.

## 📦 Installation

```bash
npm install @kevinbrenes/rampkit-core @stellar/stellar-sdk
```

## 💡 Usage

```typescript
import { RampRouter } from '@kevinbrenes/rampkit-core';

const router = new RampRouter({
  network: 'testnet',
  anchors: {
    etherfuse: { apiKey: 'YOUR_ETHERFUSE_API_KEY', sandbox: true },
    manteca:   { apiKey: 'YOUR_MANTECA_API_KEY', sandbox: true },
    koywe:     { apiKey: 'YOUR_KOYWE_API_KEY', sandbox: true },
  },
});

// Fetch quotes from all anchors in parallel
const quotes = await router.getQuotes({
  direction: 'on-ramp',
  sourceAsset: 'BRL',
  destAsset: 'USDC',
  amount: '100',
  country: 'BR',
});
```

## 📄 License

MIT © RampKit LATAM Team
